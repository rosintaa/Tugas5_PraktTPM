package com.example.recycleview;

public class Model {
    private String namaTeam;
    private int lambangTeam;
    private String privew;

    public String getNamaTeam() {
        return namaTeam;
    }

    public void setNamaTeam(String namaTeam) {
        this.namaTeam = namaTeam;
    }

    public int getLambangTeam() {
        return lambangTeam;
    }

    public void setLambangTeam(int lambangTeam) {
        this.lambangTeam = lambangTeam;
    }

    public String getPrivew() {
        return privew;
    }

    public void setPrivew(String privew) {
        this.privew = privew;
    }
}
